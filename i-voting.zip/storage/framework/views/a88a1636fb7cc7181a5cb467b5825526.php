<?php $__env->startSection('content'); ?>
    <div class="page-bg">
        <div class="login-box">
            <h2 class="page-title">Voter Login</h2>

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p style="color:red"><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <form method="POST" action="/login">
                <?php echo csrf_field(); ?>

                <div class="input-group">
                    <label>Citizenship Number</label><br>
                    <input type="text" name="citizenship_no" placeholder="Enter your citizenship number." required>
                </div>
                <br><br>

                <div class="input-group">
                    <label for="voter_id">Voter ID</label>
                    <input type="text" name="voter_id" id="voter_id" placeholder="Enter your voter id"required>
                </div>

                <!--continue buttons-->
                <div class="continue-btn">
                    <button class="btn btn-primary vote-button">Continue</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.voting', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Bdsa/Server-side/i-Voting/resources/views/login.blade.php ENDPATH**/ ?>