<?php $__env->startSection('content'); ?>
    <div class="mail-container">

        <!-- Envelope -->
        <div class="envelope">
            <div class="flap"></div>

            <div class="letter">
                <h2>Thank You for Voting!</h2>
                <p>Your vote has been successfully recorded.</p>

                <div class="actions">
                    <a href="/" class="btn-link">Back to Home</a>
                    <a href="/results" class="btn-link">View Live Results</a>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.voting', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Bdsa/Server-side/i-Voting/resources/views/thankyou.blade.php ENDPATH**/ ?>