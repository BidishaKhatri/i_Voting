<?php $__env->startSection('content'); ?>
    <div class="home-page page-bg">

        <img src="<?php echo e(asset('css/images/ballot_box.jpg')); ?>" class="ballot">

        <h2>Official Online Voting Portal</h2>

        <p class="subtitle">
            Secure, fast, and accessible voting at your fingertips.
        </p>

        <p class="trust-text">
            This platform ensures secure and transparent digital voting for all eligible citizens.
        </p>

        <div class="how-it-works">
            <h3>How It Works</h3>
            <ul>
                <li>Login using your Citizenship ID</li>
                <li>Select your candidate</li>
                <li>Submit your vote securely</li>
            </ul>
        </div>

        <a href="/login" class="btn btn-primary vote-button">
            Login & Cast Your Vote
        </a>

        <p class="footer-note">
            © 2026 Election Commission
        </p>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.voting', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Bdsa/Server-side/i-Voting/resources/views/home.blade.php ENDPATH**/ ?>