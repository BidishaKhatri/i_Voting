<?php $__env->startSection('content'); ?>
    <div class="biometric-container">

        <h2 class="page-title">Biometric Verification</h2>
        <p>Hello <?php echo e(session('voter_name') ?? ''); ?>, please verify your face to continue.</p>

        
        <div class="camera-wrapper">
            <video id="video" autoplay></video>
            <div class="oval-overlay"></div>
        </div>
        <br>

        <button class="vote-button" onclick="capture()">Verify Face</button>

        <canvas id="canvas" style="display:none;"></canvas>
        <!-- Placeholder message -->
        <div id="message"></div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/biometric.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.voting', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Bdsa/Server-side/i-Voting/resources/views/biometric.blade.php ENDPATH**/ ?>