<?php $__env->startSection('content'); ?>
    <div class="candidates-page">

        <h2 class="page-title">Choose Your Candidate</h2>

        <p>Please select one candidate to vote.</p>

        <div class="row justify-content-center">

            <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <img src="<?php echo e(asset('css/images/' . $candidate->id . '.jpg')); ?>" class="card-img-top"
                            alt="Candidate Photo">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($candidate->name); ?></h5>

                            <div class="party-info">
                                <img src="<?php echo e(asset('css/images/parties/' . str_replace(' ', '-', strtolower($candidate->party)) . '.png')); ?>"
                                    class="party-icon" alt="Party Logo">
                                
                                <span class="card-text"><?php echo e($candidate->party); ?></span>
                            </div>

                            <form method="POST" action="/candidates">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="candidate_id" value="<?php echo e($candidate->id); ?>" required>
                                <button type="submit" class="btn btn-success">Vote</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.voting', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Bdsa/Server-side/i-Voting/resources/views/candidates.blade.php ENDPATH**/ ?>