<?php $__env->startSection('content'); ?>
    <h2 class="page-title">Welcome to the Online Voting System</h2>
    <p>Please login using your voter ID to continue.</p>
    <a href="/voting/login" class="btn btn-primary vote-button">Login to Vote</a> <!--bootsrap-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.voting', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Bdsa/Server-side/election-system/resources/views/index.blade.php ENDPATH**/ ?>