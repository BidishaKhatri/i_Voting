<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>i-Voting System</title>

    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet" />
</head>

<body>
    <div class="top-banner">

        <div class="banner-left">
            <img src="<?php echo e(asset('images/nepal-logo.png')); ?>" class="logo">
            <h1>VoteNepal</h1>
        </div>

        <div class="banner-right">
            <h2>Secure Online Voting for Nepal</h2>
            <p>Vote from Anywhere, Anytime!</p>
        </div>
    </div>
    <!-- Header -->
    <header class="py-5 bg-light border-bottom mb-4">
        <div class="container">
            <div class="text-center my-5">
                <h1 class="fw-bolder">Welcome to i-Voting</h1>
                <p class="lead mb-0">A secure online voting platform</p>
            </div>
        </div>
    </header>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">i-Voting</a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent">

                <span class="navbar-toggler-icon"></span>

            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">

                <ul class="navbar-nav ms-auto">

                    <li class="nav-item"><a class="nav-link" href="/voting">Home</a></li>

                    <li class="nav-item"><a class="nav-link" href="#">Candidates</a></li>

                    <li class="nav-item"><a class="nav-link" href="#">Results</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Page Content -->
    <div class="container mt-4">

        <?php echo $__env->yieldContent('content'); ?>

    </div>

    <!-- Footer -->
    <footer class="py-5 bg-dark mt-5">
        <div class="container">
            <p class="m-0 text-center text-white">i-Voting Project</p>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>
<?php /**PATH /Users/Bdsa/Server-side/election-system/resources/views/layouts/voting.blade.php ENDPATH**/ ?>