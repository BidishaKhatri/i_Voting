<?php $__env->startSection('content'); ?>
    <div class="text-center">
        <h2>📊 Live Election Results</h2>
    </div>

    
    <div class="results-full">

        <table class="table table-bordered text-center">
            <thead>
                <tr>
                    <th>Rank</th>
                    <th>Candidate</th>
                    <th>Party</th>
                    <th>Votes</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr class="<?php echo e($index == 0 ? 'winner-row' : ''); ?>">

                        <td>
                            <?php if($index == 0): ?>
                                🏆 1
                            <?php else: ?>
                                <?php echo e($index + 1); ?>

                            <?php endif; ?>
                        </td>

                        <td><?php echo e($candidate->name); ?></td>
                        <td><?php echo e($candidate->party); ?></td>
                        <td><?php echo e($candidate->votes); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<script>
    setTimeout(() => location.reload(), 60000); //updates every 60 sec.
</script>

<?php echo $__env->make('layouts.voting', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Bdsa/Server-side/i-Voting/resources/views/results.blade.php ENDPATH**/ ?>